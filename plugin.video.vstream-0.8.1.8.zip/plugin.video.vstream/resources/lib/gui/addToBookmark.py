import xbmc
xbmc.executebuiltin("RunPlugin(plugin://video.vstream/?start='uploadlog')", True)