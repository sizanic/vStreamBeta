#-*- coding: utf-8 -*-
#Vstream https://github.com/Kodi-vStream/venom-xbmc-addons
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress
from resources.lib.multihost import cJheberg, cMultiup

import re, json

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0'

SITE_IDENTIFIER = 'ZT_cool'
SITE_NAME = 'Zone-telechargement-cool'
SITE_DESC = 'Films Séries Animés'
#URL_MAIN = 'https://zone-telechargement-1.org/'
URL_MAIN = 'https://www.zone-telechargement.cool/'
 


# MOVIE_NEWS = (URL_MAIN + 'nouveaute/', 'showMovies') # films (derniers ajouts)
# MOVIE_EXCLUS = (URL_MAIN + 'exclus/', 'showMovies') # exclus (films populaires)
# MOVIE_3D = (URL_MAIN + 'films-bluray-3d/', 'showMovies') # films en 3D
# MOVIE_HD = (URL_MAIN + 'films-bluray-hd/', 'showMovies') # films en HD
# MOVIE_HDLIGHT = (URL_MAIN + 'x265-x264-hdlight/', 'showMovies') # films en x265 et x264
# MOVIE_VOSTFR = (URL_MAIN + 'filmsenvostfr/', 'showMovies') # films VOSTFR
# MOVIE_4K = (URL_MAIN + 'film-ultra-hd-4k/', 'showMovies') # films "4k"
# MOVIE_GENRES = (URL_MAIN , 'showGenre')
# MOVIE_ANIME = (URL_MAIN + 'dessins-animes/', 'showMovies') # dessins animes
# MOVIE_BDRIP = (URL_MAIN + 'films-dvdrip-bdrip/', 'showMovies')
# MOVIE_TS_CAM = (URL_MAIN + 'scrr5tscam-films-2017/', 'showMovies')
# MOVIE_VFSTFR = (URL_MAIN + 'films-vfstfr/', 'showMovies')
# MOVIE_MKV = (URL_MAIN + 'films-mkv/', 'showMovies')
# MOVIE_VO = (URL_MAIN + 'films-vo/','showMovies')
# MOVIE_INTEGRAL = (URL_MAIN + 'collection-films-integrale/','showMovies')

MOVIES_PER_PAGE = 25

MOVIE_GENRES = (URL_MAIN + 'wp-json/wp/v2/categories?per_page=100', 'showGenre')
MOVIE_URL = (URL_MAIN + 'wp-json/wp/v2/posts?orderby=title&order=asc&per_page='+str(MOVIES_PER_PAGE)+'&categories=')
TAGS_URL = (URL_MAIN + 'wp-json/wp/v2/tags/')
POST_URL = (URL_MAIN + 'wp-json/wp/v2/posts/')
MEDIA_URL = (URL_MAIN + '/wp-json/wp/v2/media/')
                

QUALITE_URL = (URL_MAIN + 'wp-json/wp/v2/posts?tags=')



def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'Genres', 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    sSearchText = oGui.showKeyBoard()
    if (sSearchText != False):
        sUrl = sUrl + sSearchText + '&search_start=1'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return


# Récupération dynamique des catégories
def showGenre():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()
     
    contents = json.loads(sHtmlContent)
 
    if contents:
        progress_ = progress().VScreate(SITE_NAME)
        total = len(contents)
        for content in contents:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = content['name'].encode('utf-8')
            sUrl2 = MOVIE_URL + str(content['id'])
     
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl2)
             
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'genres.png', oOutputParameterHandler)
        progress_.VSclose(progress_)
 
    oGui.setEndOfDirectory()

def showMovies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    # pagination
    numPage = oInputParameterHandler.getValue('numPage')
    if not numPage:
        numPage = 1

    oRequestHandler = cRequestHandler(sUrl+'&page='+ str(numPage))
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()
    
    contents = json.loads(sHtmlContent)

    if contents:
        progress_ = progress().VScreate(SITE_NAME)
        total = len(contents)

        for content in contents:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            sTitle = content['title']['rendered'].encode('utf-8')
#            sTitle = re.sub('\[[^\]]+?]', '', sTitle) # retrait des balises [..]
            sTitle = sTitle.replace('[Streaming]','').replace('[Telecharger]','').replace('[Télécharger]','')
            sUrl2 = content['_links']['self'][0]['href']

            sDesc = content['excerpt']['rendered']
            sDesc = re.sub('<[^<]+?>', '', sDesc) # retrait des balises html

            
            sThumb = ''
            sHtmlContent = content['content']['rendered'].encode('utf-8')
            sPattern = 'data-layzr=\"(.+?)\"'
            oParser = cParser()
            aResult = oParser.parse(sHtmlContent, sPattern)
            if (aResult[0] == True):
                sThumb = aResult[1][0]

            # Thumb non trouvé ou mauvais
            if sThumb == '' or 'fbe886ed7e9a8030ac4a6a1bcbd83ec4' in sThumb:
                try:
                    idMedia = content['featured_media']
                    if idMedia == 0:
                        idMedia = content['id'] + 1
                    sThumb = getThumb(MEDIA_URL + str(idMedia))
                except:
                    pass

            sYear = ''
            sPattern = '> *(Date|Ann).+?(\d{4})'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0] == True and aResult[1][0]:
                sYear = aResult[1][0][1]

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl2)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
             
        progress_.VSclose(progress_)
        
        if total == MOVIES_PER_PAGE:
            numPage = eval(str(numPage)) + 1
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('numPage', numPage)
            oGui.addNext(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Suivant >>>[/COLOR]', oOutputParameterHandler)
            
    oGui.setEndOfDirectory()
    
    
def getThumb(sURLMedia):

    oRequestHandler = cRequestHandler(sURLMedia)
#     oRequestHandler.addHeaderEntry('User-Agent', UA)
#     oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()
    
    content = json.loads(sHtmlContent)
    return content['source_url']

# def __checkForNextPage(sHtmlContent):
#     oParser = cParser()
#     sPattern = 'href="([^"]+)"><span class="fa fa-arrow-right">'
#     aResult = oParser.parse(sHtmlContent, sPattern)
#     if (aResult[0] == True):
#         nextPage = aResult[1][0]
#         if not nextPage.startswith('https'):
#             nextPage = URL_MAIN[:-1] + nextPage
#         return nextPage
#     return False

def showMovies_tags():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    # pagination
    numPage = oInputParameterHandler.getValue('numPage')
    if not numPage:
        numPage = 1

    oRequestHandler = cRequestHandler(sUrl+'&page='+ str(numPage))
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()
    
    contents = json.loads(sHtmlContent)

    tags = set()

    if contents:
        # un film apparait plusieurs fois mais avec des qualités différentes
        # Mais chaque titre de film ne correspond qu'à un seul tag
        # Donc on filtre par tag unique
        for content in contents:
            idTag = content['tags']
            if idTag and idTag[0]:
                tags.add(idTag[0])

        progress_ = progress().VScreate(SITE_NAME)
        total = len(tags)
        for tag in tags:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            oRequestHandler = cRequestHandler(TAGS_URL + str(tag))
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
            sHtmlContent = oRequestHandler.request()

            content = json.loads(sHtmlContent)

            sTitle = content['name'].encode('utf-8')
            sTitle = sTitle.replace('[Streaming]','').replace('[Telecharger]','').replace('[Télécharger]','')
            sUrl2 = QUALITE_URL + str(tag)
#             sUrl2 = content['link']

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl2)
             
            oGui.addMovie(SITE_IDENTIFIER, 'showMoviesLinks', sTitle, '', 'genres.png', '', oOutputParameterHandler)
        progress_.VSclose(progress_)
        
        if total > 0:
            numPage = eval(str(numPage)) + 1
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('numPage', numPage)
            oGui.addNext(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Suivant >>>[/COLOR]', oOutputParameterHandler)
            
    oGui.setEndOfDirectory()
    
# def __checkForNextPage(sHtmlContent):
#     oParser = cParser()
#     sPattern = 'href="([^"]+)"><span class="fa fa-arrow-right">'
#     aResult = oParser.parse(sHtmlContent, sPattern)
#     if (aResult[0] == True):
#         nextPage = aResult[1][0]
#         if not nextPage.startswith('https'):
#             nextPage = URL_MAIN[:-1] + nextPage
#         return nextPage
#     return False

def showMoviesLinks():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl = oInputParameterHandler.getValue('siteUrl')

    #Affichage du texte
    oGui.addText(SITE_IDENTIFIER, '[COLOR olive]Qualités disponibles pour ce film :[/COLOR]')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()
    
    contents = json.loads(sHtmlContent)

    if contents:
        progress_ = progress().VScreate(SITE_NAME)
        total = len(contents)
        for content in contents:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = content['title']['rendered'].encode('utf-8')
            sTitle = sTitle.replace('[Streaming]','').replace('[Telecharger]','').replace('[Télécharger]','')
            sUrl2 = POST_URL + str(content['id'])
    
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl2)
             
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', 'genres.png', '', oOutputParameterHandler)

        progress_.VSclose(progress_)

    oGui.setEndOfDirectory()


def showHosters():
    oGui = cGui()
    oHosterGui = cHosterGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sThumb=oInputParameterHandler.getValue('sThumb')

    UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20100101 Firefox/70.0'
    oRequestHandler = cRequestHandler(sUrl.replace(' ', '%20'))
#     oRequestHandler.addHeaderEntry('User-Agent', UA)
#     oRequestHandler.addHeaderEntry('Accept-Encoding', 'gzip, deflate')
    sHtmlContent = oRequestHandler.request()

    content = json.loads(sHtmlContent)
    sHtmlContent = content['content']['rendered'].encode('utf-8')

    oParser = cParser()
    sPattern = 'large button .+?href="(.+?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if (aResult[0] == True):
        for sHosterUrl in aResult[1]:

#             sHoster = aEntry[1]
#             sHosterUrl = aEntry[0]
            
            # lien captcha
            if 'cut-urls.com' in sHosterUrl or 'cutwin.com' in sHosterUrl:
                isUrl = sHosterUrl.index('url=')
                if isUrl>0:
                    sHosterUrl = sHosterUrl[isUrl+4:]

            #pour récuperer le lien jwplayer(GoogleDrive)
            if 'filmhdstream' in sHosterUrl:
                oRequestHandler = cRequestHandler(sHosterUrl)
                sHtmlContent = oRequestHandler.request()
                sPattern = '<iframe.+?src="([^"]+)"'
                aResult = oParser.parse(sHtmlContent, sPattern)
                if (aResult[0] == True):
                    sHosterUrl = aResult[1][0]
            elif 'jheberg' in sHosterUrl:
                aResult = cJheberg().GetUrls(sHosterUrl)
                if (aResult):
                    for aEntry in aResult:
                        sHosterUrl = aEntry
                        oHoster = cHosterGui().checkHoster(sHosterUrl)
                        if (oHoster != False):
                            oHoster.setDisplayName(sMovieTitle)
                            oHoster.setFileName(sMovieTitle)
                            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
                sHosterUrl = ''
            elif 'multiup' in sUrl:
                aResult = cMultiup().GetUrls(sUrl)
        
                if (aResult):
                    for aEntry in aResult:
                        sHosterUrl = aEntry
        
                        oHoster = cHosterGui().checkHoster(sHosterUrl)
                        if (oHoster != False):
                            oHoster.setDisplayName(sMovieTitle)
                            oHoster.setFileName(sMovieTitle)
                            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
                sHosterUrl = ''

            oHoster = oHosterGui.checkHoster(sHosterUrl)
            if not oHoster:
                continue

            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            oHosterGui.showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

